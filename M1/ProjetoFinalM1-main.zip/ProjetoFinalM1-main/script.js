
/*const btnStart = document.querySelector('#start');
const sobre = document.querySelector('.sobre');
const btnSair = document.querySelector('.sair-info');
const main = document.querySelector('.main');
const btnContinuar = document.querySelector('.continuar-info');
const sectionQuiz = document.querySelector('.section_quiz');
const homeContext = document.querySelector('.home_contexto');
const header = document.querySelector('.header');

btnStart.onclick = () => {
	sobre.classList.add('active');
	main.classList.add('active');
}

btnSair.onclick = () => {
	sobre.classList.remove('active');
	main.classList.remove('active');
}


btnContinuar.onclick = () => {
	sectionQuiz.classList.add('active');
	sobre.classList.remove('active');
	main.classList.remove('active');
	homeContext.classList.add('remover');
	header.classList.add('remover');
}*/




// Função para lidar com a resposta correta
/*function respostaCerta() {
	// Exibir a próxima pergunta
	document.getElementById('quiz1').style.display = 'none'; // Esconder a pergunta atual
	document.getElementById('quiz2').style.display = 'block'; // Exibir a próxima pergunta
  }
  
  // Função para lidar com respostas incorretas (opcional)
  function respostaErrada() {
	// Adicione aqui o código para lidar com respostas incorretas, se necessário
  }*/


// Fiquei com dúvida em relação a este código


// var container1 = document.querySelector('#home');
// var container2 = document.querySelector('#quiz1')
// btn.addEventListener('click', function() {
//     if(container1.style.display === 'block') {
//         container1.style.display = 'none';
//     } else {
//         container1.style.display = 'block';
//     }

//     if (container1.style.display === 'none') {
//         container2.style.display = 'block'
//     }
// });

// var container = document.getElementsByTagName("#quiz1");
// var respostas = document.getElementsByTagName("button");
// var indice = 0;

// function respostaCerta() {
// 	alert("Resposta correta!");
// 	proximaPergunta();
// }

// function respostaErrada() {
// 	alert("Resposta incorreta!");
// }

// function proximaPergunta() {
// 	indice++;
// 	if (indice < container.length) {
// 		container[indice-1].style.display = "none";
// 		respostas[indice-1].style.display = "none";
// 		container[indice].style.display = "block";
// 		respostas[indice].style.display = "block";
// 	} else {
// 		alert("Fim do quiz!");
// 	}
// };
