/*let questoes = [
    {
        numb: 1,
        questao: "Qual é a função do comando console.log()",
        resposta:"c. Exibe mensagem no Console do navegador.",
        opcao:[
            "a. Realizar uma operação matemática.",
            "b. Um sistema operacional.",
            "c. Exibe mensagem no Console do navegador.",
            "d. Criar uma variável."
        ]
    },
    {
        numb: 2,
        questao: "",
        resposta:"",
        opcao:[

        ]
    },
    {
        numb: 3,
        questao: "",
        resposta:"",
        opcao:[

        ]
    },
    {
        numb: 4,
        questao: "",
        resposta:"",
        opcao:[

        ]
    },
    {
        numb: 5,
        questao: "",
        resposta:"",
        opcao:[

        ]
    },
    {
        numb: 6,
        questao: "",
        resposta:"",
        opcao:[

        ]
    },

]*/